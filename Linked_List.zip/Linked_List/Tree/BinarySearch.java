import java.util.Scanner;
class Node{
    int data;
    Node right;
    Node left;
    Node(int data){
        this.data=data;
        this.left=null;
        this.right=null;
    }
}
public class BinarySearch {
    Node root=null;
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        BinarySearch tree=new BinarySearch();
        
    }
}
