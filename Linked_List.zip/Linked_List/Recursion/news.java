import java.util.Scanner;

class Node {
    Node prev;
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

class news{
    Node head;
    Node tail;

    news() {
        this.head = null;
        this.tail = null;
    }

    void insert(int data) {
        Node newnode = new Node(data);
        if (head == null) {
            head = newnode;
            tail = newnode;
        } else {
            tail.next = newnode;
            newnode.prev = tail;
            tail = newnode;
        }
    }

    void display() {
        Node temp = tail;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.prev;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        news dll = new news();
        while (true) {
            int n = sc.nextInt();
            if (n == -1) {
                break;
            }
            dll.insert(n);
        }
        dll.display();
    }
}
