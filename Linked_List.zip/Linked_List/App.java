import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class App {
    public static boolean isAncestorsLocked(int work_ind, int[] lock, int max_child_for_node) {
        int parent_ind = work_ind;
        if (work_ind == 0)
            return false;
        while (true) {
            parent_ind = (parent_ind - 1) / max_child_for_node; // ancestor calculation
            if (lock[parent_ind] != -1) // if any parent is locked return true
                return true;
            if (parent_ind == 0)
                return false;
        }
    }

    public static boolean isDescendantsLocked(int work_ind, int[] lock, int max_child_for_node, int tot_nodes) {
        Queue<Integer> que = new LinkedList<>();
        que.add(work_ind);
        while (que.isEmpty() == false) {
            int deq_ind, val, child_ind;
            deq_ind = que.poll();
            if (lock[deq_ind] != -1) // descendant is locked
                return true;
            for (val = 1; val <= max_child_for_node; val++) {
                child_ind = deq_ind * max_child_for_node + val;
                if (child_ind < tot_nodes)
                    que.add(child_ind);
            }
        }
        return false;
    }

    public static void unlockAllDescendants(int work_ind, int[] lock, int max_child_for_node, int tot_nodes) {
        Queue<Integer> que = new LinkedList<>();
        que.add(work_ind);
        while (que.isEmpty() == false) {
            int deq_ind, val, child_ind;
            deq_ind = que.poll();
            if (lock[deq_ind] != -1) // descendant is locked
                lock[deq_ind] = -1;
            for (val = 1; val <= max_child_for_node; val++) {
                child_ind = deq_ind * max_child_for_node + val;
                if (child_ind < tot_nodes)
                    que.add(child_ind);
            }
        }
    }

    public static boolean upGradeDescendantsCheck(int work_ind, int[] lock, int max_child_for_node, int tot_nodes, int qry_id) {
        Queue<Integer> que = new LinkedList<>();
        que.add(work_ind);
        int lock_ctr = 0;
        while (que.isEmpty() == false) {
            int deq_ind, val, child_ind;
            deq_ind = que.poll();
            if (lock[deq_ind] != -1 && lock[deq_ind] != qry_id) // descendant is locked by different id
                return false;
            if (lock[deq_ind] == qry_id)
                lock_ctr++;
            for (val = 1; val <= max_child_for_node; val++) {
                child_ind = deq_ind * max_child_for_node + val;
                if (child_ind < tot_nodes)
                    que.add(child_ind);
            }
        }
        return lock_ctr != 0;
    }

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        
        String[] nodes = {"World", "Asia", "Africa", "China", "India", "SouthAfrica", "Egypt"};
        int tot_nodes = 7;
        int max_child_for_node = 2;
        
        int[] lock = new int[tot_nodes];
        for (int ind = 0; ind < tot_nodes; ind++)
            lock[ind] = -1;
        
        HashMap<String, Integer> node_map = new HashMap<>();
        for (int ind = 0; ind < tot_nodes; ind++) {
            node_map.put(nodes[ind], ind);
        }

        System.out.print("Enter number of queries: ");
        int num_queries = sc.nextInt();
        
        for (int q_ind = 0; q_ind < num_queries; q_ind++) {
            System.out.print("Enter query type (1 for lock, 2 for unlock, 3 for upgrade): ");
            int work_qry_no = sc.nextInt();
            System.out.print("Enter node name: ");
            String work_qry_node = sc.next();
            System.out.print("Enter query ID: ");
            int work_qry_id = sc.nextInt();
            
            int work_qry_ind = node_map.get(work_qry_node); // convert node (string) to index
            
            if (work_qry_no == 1) { // lock
                if (lock[work_qry_ind] != -1)
                    System.out.println("false");
                else if (isAncestorsLocked(work_qry_ind, lock, max_child_for_node))
                    System.out.println("false");
                else if (isDescendantsLocked(work_qry_ind, lock, max_child_for_node, tot_nodes))
                    System.out.println("false");
                else {
                    lock[work_qry_ind] = work_qry_id; // locking
                    System.out.println("true");
                }
            } else if (work_qry_no == 2) { // unlock
                if (lock[work_qry_ind] == work_qry_id) { // check whether it's already locked by the same id
                    lock[work_qry_ind] = -1; // unlocking
                    System.out.println("true");
                } else {
                    System.out.println("false");
                }
            } else if (work_qry_no == 3) { // upgrade
                if (lock[work_qry_ind] == -1) { // it should be unlocked to upgrade
                    if (isAncestorsLocked(work_qry_ind, lock, max_child_for_node))
                        System.out.println("false");
                    else if (upGradeDescendantsCheck(work_qry_ind, lock, max_child_for_node, tot_nodes, work_qry_id) == false)
                        System.out.println("false");
                    else { // upgrade
                        unlockAllDescendants(work_qry_ind, lock, max_child_for_node, tot_nodes);
                        lock[work_qry_ind] = work_qry_id; // locking
                        System.out.println("true");
                    }
                } else // it's already locked
                    System.out.println("false");
            }
        }

        sc.close();
    }
}
