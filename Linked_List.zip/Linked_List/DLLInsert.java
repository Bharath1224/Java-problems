import java.util.Scanner;

class Node {
    Node prev;
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

class DLLInsert {
    Node head;
    Node tail;

    DLLInsert() {
        this.head = null;
        this.tail = null;
    }

    void insert(int data) {
        Node newnode = new Node(data);
        if (head == null) {
            head = newnode;
            tail = newnode;
        } else {
            tail.next = newnode;
            newnode.prev = tail;
            tail = newnode;
        }
    }

    void display() {
        Node temp = tail;
        while (temp.prev != null) {
            System.out.print(temp.data + " ");
            temp = temp.prev;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DLLInsert dll = new DLLInsert();
        while (true) {
            int n = sc.nextInt();
            if (n == -1) {
                break;
            }
            dll.insert(n);
        }
        dll.display();
    }
}
